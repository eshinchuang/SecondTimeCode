﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI3 : MonoBehaviour
{
    float cooldown;
    public GameObject bullet;
    GameObject player;
    Animator EnemyAni;
    SpriteRenderer spr;
    private float speed;
    private Vector2 firepos1;
    private Vector2 firepos2;
    
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("player");
        EnemyAni = this.gameObject.GetComponent<Animator>();
        EnemyAni.SetBool("attack", false);
        spr = this.gameObject.GetComponent<SpriteRenderer>();
        spr.flipX = false;
    }

    // Update is called once per frame
    void Update()
    {
        spr.flipX = (player.transform.position.x > transform.position.x) ? true : false;
    }

    void FixedUpdate() {
        if(EnemyAni.GetBool("attack")){
            EnemyAni.SetBool("attack", false);
        }
        Shoot();
    }

    private void Shoot(){
        if(cooldown <= 0){
            EnemyAni.SetBool("attack", true);
            firepos1 = new Vector2(transform.position.x - 0.1f, transform.position.y + 0.1f);
            firepos2 = new Vector2(transform.position.x + 0.3f, transform.position.y + 0.1f);
            Instantiate(bullet, firepos1, Quaternion.identity);
            Instantiate(bullet, firepos2, Quaternion.identity);
            cooldown = Random.Range(2.0f, 2.5f);
        }
        else{
            cooldown -= Time.deltaTime;
        }
    }
}
