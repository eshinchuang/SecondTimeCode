﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquitmentController : MonoBehaviour
{
    GameObject player;
    Vector2 target;
    Vector2 dir;
    float speed;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("player");
        speed = (player.transform.position - transform.position).magnitude;
        if(speed < player.GetComponent<PlayerController>().speed + 1) speed = player.GetComponent<PlayerController>().speed + 1;
        Destroy(this.gameObject, 3);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
        transform.Rotate(new Vector3(0, 0, 6));
        if(transform.position == player.transform.position){
            Destroy(this.gameObject);
        }
    }
}
